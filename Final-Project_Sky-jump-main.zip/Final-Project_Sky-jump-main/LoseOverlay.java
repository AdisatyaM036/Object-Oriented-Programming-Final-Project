import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LoseOverlay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LoseOverlay extends Actor
{
    /**
     * Act - do whatever the LoseOverlay wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public LoseOverlay(){
        GreenfootImage image = getImage();
        image.scale(1080,700);
        setRotation(90);
    }
    public void act()
    {
        
    }
}
